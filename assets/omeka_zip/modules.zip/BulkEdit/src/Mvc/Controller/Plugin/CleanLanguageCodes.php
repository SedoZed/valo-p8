<?php declare(strict_types=1);

namespace BulkEdit\Mvc\Controller\Plugin;

use Common\Stdlib\EasyMeta;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\EntityManager;
use Laminas\Log\LoggerInterface;
use Laminas\Mvc\Controller\Plugin\AbstractPlugin;

class CleanLanguageCodes extends AbstractPlugin
{
    /**
     * @var EasyMeta
     */
    protected $easyMeta;

    /**
     * @var EntityManager
     */
    protected $entityManager;

    /**
     * The logger is required, because there is no controller during job.
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @param EntityManager $entityManager
     * @param LoggerInterface $logger
     */
    public function __construct(
        EasyMeta $easyMeta,
        EntityManager $entityManager,
        LoggerInterface $logger
    ) {
        $this->easyMeta = $easyMeta;
        $this->entityManager = $entityManager;
        $this->logger = $logger;
    }

    /**
     * Clean and modify from a language code to another one as a whole.
     *
     * @param array|null $resourceIds Passing an empty array means that there is
     * no ids to process. To process all values, pass a null or no argument.
     * @param string|null $from
     * @param string|null $to
     * @param array|null $properties
     * @return int Number of cleaned values.
     */
    public function __invoke(?array $resourceIds = null, ?string $from = '', ?string $to = '', ?array $properties = []): int
    {
        if ($resourceIds !== null) {
            $resourceIds = array_filter(array_map('intval', $resourceIds));
            if (!count($resourceIds)) {
                return 0;
            }
        }

        // Use a direct query: during a post action, data are already flushed.
        // The entity manager may be used directly, but it is simpler with sql.
        $connection = $this->entityManager->getConnection();

        $bind = [];
        $types = [];

        $quotedFrom = empty($from)
            ? '"" OR `v`.`lang` IS NULL'
            : $connection->quote($from);
        $quotedTo = empty($to)
            ? 'NULL'
            : $connection->quote($to);

        $sql = <<<SQL
            UPDATE `value` AS `v`
            SET
                `v`.`lang` = $quotedTo
            WHERE
                `v`.`lang` = $quotedFrom
            SQL;

        if ($resourceIds !== null) {
            $sql .= "\n" . <<<'SQL'
                AND `v`.`resource_id` IN (:resource_ids)
                SQL;
            $bind['resource_ids'] = $resourceIds;
            $types['resource_ids'] = Connection::PARAM_INT_ARRAY;
        }

        if ($properties && !in_array('all', $properties)) {
            $propertyIds = $this->easyMeta->propertyIds($properties);
            if ($propertyIds) {
                $sql .= "\n" . <<<'SQL'
                    AND `v`.`property_id` IN (:property_ids)
                    SQL;
                $bind['property_ids'] = array_values($propertyIds);
                $types['property_ids'] = Connection::PARAM_INT_ARRAY;
            } else {
                $sql .= "\n" . <<<'SQL'
                    AND 1 = 1
                    SQL;
            }
        }

        $count = $connection->executeStatement($sql, $bind, $types);
        if ($count) {
            $this->logger->info(
                'Updated language from "{from}" to "{to}" of {count} values.', // @translate
                ['from' => $from, 'to' => $to, 'count' => $count]
            );
        }

        return (int) $count;
    }
}
