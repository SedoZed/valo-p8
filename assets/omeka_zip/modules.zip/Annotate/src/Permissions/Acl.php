<?php declare(strict_types=1);

namespace Annotate\Permissions;

class Acl extends \Omeka\Permissions\Acl
{
    const ROLE_ANNOTATOR = 'annotator';
}
