SET foreign_key_checks = 0;
DROP TABLE IF EXISTS `resource_template_property_data`;
DROP TABLE IF EXISTS `resource_template_data`;
