SET foreign_key_checks = 0;
DROP TABLE IF EXISTS `bulk_export`;
DROP TABLE IF EXISTS `bulk_exporter`;
DROP TABLE IF EXISTS `bulk_shaper`;
DROP TABLE IF EXISTS `value_data`;
DROP TRIGGER IF EXISTS `tr_value_data_insert`;
DROP TRIGGER IF EXISTS `tr_value_data_update`;
