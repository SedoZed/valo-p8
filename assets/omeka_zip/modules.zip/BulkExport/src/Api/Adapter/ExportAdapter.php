<?php declare(strict_types=1);

namespace BulkExport\Api\Adapter;

use BulkExport\Api\Representation\ExportRepresentation;
use BulkExport\Entity\Export;
use Doctrine\Inflector\InflectorFactory;
use Doctrine\ORM\QueryBuilder;
use Omeka\Api\Adapter\AbstractEntityAdapter;
use Omeka\Api\Request;
use Omeka\Entity\EntityInterface;
use Omeka\Stdlib\ErrorStore;

class ExportAdapter extends AbstractEntityAdapter
{
    protected $sortFields = [
        'id' => 'id',
        'exporter_id' => 'exporter',
        'owner_id' => 'owner',
        'job_id' => 'job',
        'comment' => 'comment',
        'filename' => 'filename',
    ];

    protected $scalarFields = [
        'id' => 'id',
        'exporter' => 'exporter',
        'owner' => 'owner',
        'job' => 'job',
        'comment' => 'comment',
        'params' => 'params',
        'filename' => 'filename',
    ];

    public function getResourceName()
    {
        return 'bulk_exports';
    }

    public function getRepresentationClass()
    {
        return ExportRepresentation::class;
    }

    public function getEntityClass()
    {
        return Export::class;
    }

    public function buildQuery(QueryBuilder $qb, array $query): void
    {
        $expr = $qb->expr();

        if (isset($query['exporter_id'])) {
            $qb->andWhere($expr->eq(
                'omeka_root.exporter',
                $this->createNamedParameter($qb, $query['exporter_id'])
            ));
        }

        if (isset($query['job_id'])) {
            $qb->andWhere($expr->eq(
                'omeka_root.job',
                $this->createNamedParameter($qb, $query['job_id'])
            ));
        }

        if (isset($query['job_status'])) {
            $jobAlias = $this->createAlias();
            $qb
                ->innerJoin('omeka_root.job', $jobAlias)
                ->andWhere($expr->eq(
                    "$jobAlias.status",
                    $this->createNamedParameter($qb, $query['job_status'])
                ));
        }

        if (isset($query['owner_id']) && is_numeric($query['owner_id'])) {
            $userAlias = $this->createAlias();
            $qb
                ->innerJoin('omeka_root.owner', $userAlias)
                ->andWhere($expr->eq(
                    'omeka_root.owner',
                    $this->createNamedParameter($qb, $query['owner_id'])
                ));
        }
    }

    public function hydrate(Request $request, EntityInterface $entity, ErrorStore $errorStore): void
    {
        $data = $request->getContent();
        $inflector = InflectorFactory::create()->build();
        foreach ($data as $key => $value) {
            $posColon = strpos($key, ':');
            $keyName = $posColon === false ? $key : substr($key, $posColon + 1);
            $method = 'set' . ucfirst($inflector->camelize($keyName));
            if (method_exists($entity, $method)) {
                $entity->$method($value);
            }
        }
    }

    public function deleteEntity(Request $request)
    {
        /** @var \BulkExport\Entity\Export $entity */
        $entity = parent::deleteEntity($request);

        // Deletion rights is already checked.
        $filename = $entity->getFilename();
        if (!$filename) {
            return $entity;
        }

        // Check if using custom path (absolute) or default location (relative).
        if (mb_substr($filename, 0, 1) === '/') {
            // Custom path: use local file system.
            if (file_exists($filename) && is_writeable($filename)) {
                @unlink($filename);
            }
        } else {
            // Default location: use Omeka's file store (supports S3, etc.).
            try {
                /** @var \Omeka\File\Store\StoreInterface $store */
                $store = $this->getServiceLocator()->get('Omeka\File\Store');
                $store->delete('bulk_export/' . $filename);
            } catch (\Exception $e) {
                // Silently ignore deletion errors (file may not exist).
            }
        }

        return $entity;
    }
}
