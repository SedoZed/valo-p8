<?php declare(strict_types=1);

namespace BulkExport\Api\Representation;

use BulkExport\Formatter\Manager as FormatterManager;
use Omeka\Api\Representation\AbstractEntityRepresentation;

class ExporterRepresentation extends AbstractEntityRepresentation
{
    /**
     * @var \BulkExport\Formatter\Manager
     */
    protected $formatterManager;

    /**
     * @var \BulkExport\Formatter\FormatterInterface
     */
    protected $formatter;

    public function getControllerName()
    {
        return 'exporter';
    }

    public function getJsonLdType()
    {
        return 'o-bulk:Exporter';
    }

    public function getJsonLd()
    {
        $owner = $this->owner();
        return [
            'o:id' => $this->id(),
            'o:owner' => $owner ? $owner->getReference()->jsonSerialize() : null,
            'o:label' => $this->label(),
            'o-bulk:formatter' => $this->formatterName(),
            'o:config' => $this->config(),
        ];
    }

    public function getResource(): \BulkExport\Entity\Exporter
    {
        return $this->resource;
    }

    public function owner(): ?\Omeka\Api\Representation\UserRepresentation
    {
        $user = $this->resource->getOwner();
        return $user
            ? $this->getAdapter('users')->getRepresentation($user)
            : null;
    }

    public function label(): string
    {
        return $this->resource->getLabel();
    }

    public function config(): array
    {
        return $this->resource->getConfig();
    }

    public function configOption(string $part, $key)
    {
        $conf = $this->resource->getConfig();
        return $conf[$part][$key] ?? null;
    }

    /**
     * Get the formatter name (alias like 'csv', 'ods', etc.).
     */
    public function formatterName(): ?string
    {
        return $this->resource->getFormatter();
    }

    /**
     * Get the formatter instance.
     */
    public function formatter(): ?\BulkExport\Formatter\FormatterInterface
    {
        if ($this->formatter) {
            return $this->formatter;
        }

        $formatterName = $this->formatterName();
        if (!$formatterName) {
            return null;
        }

        $manager = $this->getFormatterManager();
        if (!$manager->has($formatterName)) {
            return null;
        }

        $this->formatter = $manager->get($formatterName);
        return $this->formatter;
    }

    /**
     * Get the formatter label.
     */
    public function formatterLabel(): ?string
    {
        $formatter = $this->formatter();
        return $formatter ? $formatter->getLabel() : $this->formatterName();
    }

    /**
     * Get the formatter config.
     */
    public function formatterConfig(): array
    {
        $conf = $this->config();
        return $conf['formatter'] ?? [];
    }

    protected function getFormatterManager(): FormatterManager
    {
        if (!$this->formatterManager) {
            $this->formatterManager = $this->getServiceLocator()->get(FormatterManager::class);
        }
        return $this->formatterManager;
    }

    /**
     * Get the config form class for this formatter.
     */
    public function getConfigFormClass(): ?string
    {
        $formatterName = $this->formatterName();
        if (!$formatterName) {
            return null;
        }

        $config = $this->getServiceLocator()->get('Config');
        $formatterForms = $config['formatter_forms'] ?? [];

        return $formatterForms[$formatterName]['config'] ?? null;
    }

    /**
     * Get the params form class for this formatter.
     */
    public function getParamsFormClass(): ?string
    {
        $formatterName = $this->formatterName();
        if (!$formatterName) {
            return null;
        }

        $config = $this->getServiceLocator()->get('Config');
        $formatterForms = $config['formatter_forms'] ?? [];

        return $formatterForms[$formatterName]['params'] ?? null;
    }

    public function exporterConfig(): array
    {
        $conf = $this->config();
        return $conf['exporter'] ?? [];
    }

    public function adminUrl($action = null, $canonical = false)
    {
        $url = $this->getViewHelper('Url');
        return $url(
            'admin/bulk-export/id',
            [
                'controller' => $this->getControllerName(),
                'action' => $action,
                'id' => $this->id(),
            ],
            ['force_canonical' => $canonical]
        );
    }

    /**
     * Get the display title for this resource.
     *
     * @param string|null $default
     * @param array|string|null $lang
     * @return string|null
     *
     * @see \Omeka\Api\Representation\AbstractResourceRepresentation::displayTitle()
     */
    public function displayTitle($default = null, $lang = null)
    {
        $title = $this->label();
        if ($title === null || $title === '') {
            if ($default === null || $default === '') {
                $translator = $this->getServiceLocator()->get('MvcTranslator');
                $title = sprintf(
                    $translator->translate('Exporter #%d'), // @translate
                    $this->id()
                );
            } else {
                $title = $default;
            }
        }
        return $title;;
    }

    /**
     * Get a "pretty" link to this resource containing a thumbnail and
     * display title.
     *
     * @param string $thumbnailType Type of thumbnail to show
     * @param string|null $titleDefault See $default param for displayTitle()
     * @param string|null $action Action to link to (see link() and linkRaw())
     * @param array $attributes HTML attributes, key and value
     * @param array|string|null $lang Language IETF tag
     * @return string
     *
     * @see \Omeka\Api\Representation\AbstractResourceRepresentation::linkPretty()
     */
    public function linkPretty(
        $thumbnailType = 'square',
        $titleDefault = null,
        $action = null,
        array $attributes = null,
        $lang = null
    ) {
        $escape = $this->getViewHelper('escapeHtml');
        $thumbnail = $this->getViewHelper('thumbnail');
        $linkContent = sprintf(
            '%s<span class="resource-name">%s</span>',
            $thumbnail($this, $thumbnailType),
            $escape($this->displayTitle($titleDefault, $lang))
        );
        if (empty($attributes['class'])) {
            $attributes['class'] = 'resource-link';
        } else {
            $attributes['class'] .= ' resource-link';
        }
        return $this->linkRaw($linkContent, $action, $attributes);
    }
}
