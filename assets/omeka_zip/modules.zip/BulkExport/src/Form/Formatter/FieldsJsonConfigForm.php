<?php declare(strict_types=1);

namespace BulkExport\Form\Formatter;

class FieldsJsonConfigForm extends FieldsConfigForm
{
}
