<?php declare(strict_types=1);

namespace BulkExport\Form\Formatter;

use Laminas\Form\Element;

class CsvConfigForm extends SpreadsheetConfigForm
{
    public function appendSpecific(): self
    {
        parent::appendSpecific();

        $this
            ->add([
                'name' => 'delimiter',
                'type' => Element\Text::class,
                'options' => [
                    'label' => 'Delimiter', // @translate
                ],
                'attributes' => [
                    'id' => 'delimiter',
                    'value' => ',',
                ],
            ])
            ->add([
                'name' => 'enclosure',
                'type' => Element\Text::class,
                'options' => [
                    'label' => 'Enclosure', // @translate
                ],
                'attributes' => [
                    'id' => 'enclosure',
                    'value' => '"',
                ],
            ])
            ->add([
                'name' => 'escape',
                'type' => Element\Text::class,
                'options' => [
                    'label' => 'Escape', // @translate
                ],
                'attributes' => [
                    'id' => 'escape',
                    'value' => '\\',
                ],
            ]);
        return $this;
    }
}
