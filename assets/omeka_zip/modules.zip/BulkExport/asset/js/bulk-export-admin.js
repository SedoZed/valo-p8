'use strict';

(function() {

    $(document).ready(function() {

        // Display the specific settings of each normalization.

        /*
        function toggleSettingsNormalization() {
            // Hide all settings unchecked, then display the ones checked.
            $('input[type=checkbox][name="o:config[normalization][]"]:not(checked)').closest('.field').hide();
            const checkeds = $('input[type=checkbox][name="o:config[normalization][]"]:checked').closest('.field').show();
        }

        $('input[type=checkbox][name="o:config[normalization][]"]')
            .on('change',toggleSettingsNormalization);

        toggleSettingsNormalization();
        */

    });

})();
