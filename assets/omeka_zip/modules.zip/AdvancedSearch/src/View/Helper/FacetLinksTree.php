<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

class FacetLinksTree extends AbstractFacetTree
{
    protected $partial = 'search/facet-links';
}
