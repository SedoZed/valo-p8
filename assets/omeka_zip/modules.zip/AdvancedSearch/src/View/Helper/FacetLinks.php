<?php declare(strict_types=1);

namespace AdvancedSearch\View\Helper;

class FacetLinks extends AbstractFacet
{
    protected $partial = 'search/facet-links';
}
