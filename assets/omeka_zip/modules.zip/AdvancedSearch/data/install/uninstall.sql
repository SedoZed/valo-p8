SET foreign_key_checks = 0;
DROP TABLE IF EXISTS `search_suggestion`;
DROP TABLE IF EXISTS `search_suggester`;
DROP TABLE IF EXISTS `search_config`;
DROP TABLE IF EXISTS `search_engine`;
